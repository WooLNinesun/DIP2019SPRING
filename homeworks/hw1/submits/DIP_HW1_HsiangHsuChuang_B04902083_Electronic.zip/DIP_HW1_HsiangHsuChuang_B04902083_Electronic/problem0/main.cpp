#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256

class Solution: public Basic {
    public:
        Solution(
            const char* filepath, unsigned height, unsigned width, unsigned pixelbyte
        ) : Basic(filepath, height, width, pixelbyte) {}
	public:
		void process_horizontal_flipping() {
            for ( int i = 0; i < IMG_SIZE; i++ ) {
                for ( int j = 0; j < IMG_SIZE/2; j++ ) {
                    swap( this->image(0, i, j), this->image(0, i, 255-j) );
                }
            }
		}
		void process_power_law( double p ) {
            unsigned c = 1;
            for ( int i = 0; i < IMG_SIZE; i++ ) {
                for ( int j = 0; j < IMG_SIZE; j++ ) {
                    double pixel = (double)this->image(0, i, j);
                    this->image(0, i, j) = c * pow ( pixel/255.0, p ) * 255;
                }
            }
		}
};

int main( int argc, char* argv[] ) {
    if ( argc == 2 ) {
        try {
			Solution warmup( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			warmup.process_horizontal_flipping();
			warmup.output( "B_process_horizontal_flipping.raw" );
			warmup.process_power_law( 1.2 );
			warmup.output( "B_power_law_1.2.raw" );
        } catch (const char err[]) {
            printf("%s\n", err);
        }   
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}
