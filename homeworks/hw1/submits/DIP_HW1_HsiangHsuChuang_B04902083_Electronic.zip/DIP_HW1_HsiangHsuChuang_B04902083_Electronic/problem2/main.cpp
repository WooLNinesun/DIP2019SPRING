#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256

unsigned char abssub(unsigned char a, unsigned char b) { return (a > b)? a-b : b-a; }

class Solution: public Basic {
    public:
        Solution(
            const char* filepath, unsigned height, unsigned width, unsigned pixelbyte
        ) : Basic(filepath, height, width, pixelbyte) {}
	public:
        int find_symmetry( int n ) {
            if (n < 0)
                return -n + 1;
            if (n >= IMG_SIZE)
                return IMG_SIZE * 2 - 1 - n;
            return n;
        }
        void process_low_pass_filter( double b )  {
            int half = 1;
            double denominator = pow(b + 2, 2);
            double tmp1 = 1 / denominator;
            double tmp2 = tmp1 * b;
            double tmp3 = tmp2 * b;
            double filter[3][3] = {
                {tmp1, tmp2, tmp1},
                {tmp2, tmp3, tmp2},
                {tmp1, tmp2, tmp1}
            };

            vector<unsigned char> temp(this->image.size(), 0);
            for (int i = 0; i < IMG_SIZE; i++) {
                for (int j = 0; j < IMG_SIZE; j++) {
                    double sum = 0;
                    for (int k = i - half, fi = 0; k <= i + half; k++, fi++) {
                        int x = find_symmetry(k);
                        for (int l = j - half, fj = 0; l <= j + half; l++, fj++) {
                            int y = find_symmetry(l);
                            sum += filter[fi][fj] * this->image(0, x, y);
                        }
                    }
                    temp[i * IMG_SIZE + j] = sum;
                }
            }
            for ( int i = 0; i < this->image.size(); i++ ) {
                this->image.data[i] = temp[i];
            }
        }
        void process_outlier_detection( double e )  {
            vector<unsigned char> temp(this->image.size(), 0);
            for (int i = 0; i < IMG_SIZE; i++) {
                for (int j = 0; j < IMG_SIZE; j++) {
                    double sum = 0;
                    for (int k = i - 1; k <= i + 1; k++) {
                        int x = find_symmetry(k);
                        for (int l = j - 1; l <= j + 1; l++) {
                            int y = find_symmetry(l);
                            if ( k == i, l == j ) { continue; }
                            sum += this->image(0, x, y);
                        }
                    }
                    temp[i * IMG_SIZE + j] = sum/8.0;
                }
            }
            for ( int i = 0; i < this->image.size(); i++ ) {
                if ( abssub(this->image.data[i], temp[i]) > e ) {
                    this->image.data[i] = temp[i];
                }
            }
        }
        void process_median_filtering()  {
            vector<unsigned char> temp(this->image.size(), 0);
            for (int i = 0; i < IMG_SIZE; i++) {
                for (int j = 0; j < IMG_SIZE; j++) {
                    vector<unsigned char> median;
                    for (int k = i - 1; k <= i + 1; k++) {
                        int x = find_symmetry(k);
                        for (int l = j - 1; l <= j + 1; l++) {
                            int y = find_symmetry(l);
                            median.push_back(this->image(0, x, y));
                        }
                    }
                    sort (median.begin(), median.end());
                    temp[i * IMG_SIZE + j] = median[4];
                }
            }
            for ( int i = 0; i < this->image.size(); i++ ) {
                this->image.data[i] = temp[i];
            }
        }
        double computer_mse( const vector<unsigned char>& a ) {
            double total = 0;
            for (int i = 0; i < IMG_SIZE; i++) {
                for (int j = 0; j < IMG_SIZE; j++) {
                    total += pow(a[i* IMG_SIZE+j] - this->image(0, i, j), 2);	
                }
            }
            return total / (IMG_SIZE * IMG_SIZE);
        }
        double computer_psnr( const vector<unsigned char>& a ) {
            return 10 * log10(255 * 255 / computer_mse( a ));
        }
};

int main( int argc, char* argv[] ) {
    if ( argc == 4 ) {
        try {
			Solution p3_b_1( argv[2], IMG_SIZE, IMG_SIZE, 1 );
            p3_b_1.process_low_pass_filter(1.5);
            p3_b_1.output( "3.b_low_pass_filter.raw" );

			Solution p3_b_2( argv[2], IMG_SIZE, IMG_SIZE, 1 );
            p3_b_2.process_outlier_detection( 3 );
            p3_b_2.output( "3.b_outlier_detection.raw" );

			Solution p3_b_3( argv[2], IMG_SIZE, IMG_SIZE, 1 );
            p3_b_3.process_median_filtering();
            p3_b_3.output( "3.b_median_filtering.raw" );

			Solution p3_c_1( argv[3], IMG_SIZE, IMG_SIZE, 1 );
            p3_c_1.process_low_pass_filter(1.5);
            p3_c_1.output( "3.c_low_pass_filter.raw" );

			Solution p3_c_2( argv[3], IMG_SIZE, IMG_SIZE, 1 );
            p3_c_2.process_outlier_detection( 5 );
            p3_c_2.output( "3.c_outlier_detection.raw" );

			Solution p3_c_3( argv[2], IMG_SIZE, IMG_SIZE, 1 );
            p3_c_3.process_median_filtering();
            p3_c_3.output( "3.c_median_filtering.raw" );


			Solution p3_a( argv[1], IMG_SIZE, IMG_SIZE, 1 );
            printf("\n");
            printf("p3_N1 PSNR:%f\n", p3_b_1.computer_psnr(p3_a.image.data) );
            printf("p3_N2 PSNR:%f\n", p3_c_3.computer_psnr(p3_a.image.data) );

        } catch (const char err[]) {
            printf("%s\n", err);
        }
    } else {
        printf("Need 3 image file. <origin> <noise image1> <noise image2>");
    }
    return 0;
}
