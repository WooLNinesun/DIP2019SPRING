#include <cstdio>
#include <cstdlib>
#include <vector>

#ifndef __BASIC_H
#define __BASIC_H

using namespace std;

template <typename T>
class Image {
    public:
        vector<T> data;
        unsigned height;
        unsigned width;
        unsigned pixelbyte;

    public:
        Image();
        Image(unsigned height, unsigned width, unsigned pixelbyte);
        virtual ~Image();
    
    public:
        T& operator()(const unsigned& p, const unsigned& h, const unsigned& w);

    public:
        unsigned size();
        void     resize(unsigned height, unsigned width, unsigned pixelbyte);
};

class Basic {
    public:
        Image<unsigned char> image;

    public:
        Basic(const char* filepath, unsigned height, unsigned width, unsigned pixelbyte);

    public:
        void output(const char* filepath);
};

#include "basic.cpp"

#endif
