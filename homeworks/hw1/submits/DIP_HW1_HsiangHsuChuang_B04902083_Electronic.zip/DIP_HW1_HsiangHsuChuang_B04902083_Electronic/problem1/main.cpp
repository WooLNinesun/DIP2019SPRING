#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256

class Solution: public Basic {
    public:
        Solution(
            const char* filepath, unsigned height, unsigned width, unsigned pixelbyte
        ) : Basic(filepath, height, width, pixelbyte) {}
	public:
		void process_intensity_dividing( unsigned d ) {
            for ( int i = 0; i < IMG_SIZE; i++ ) {
                for ( int j = 0; j < IMG_SIZE; j++ ) {
                    this->image(0, i, j) = this->image(0, i, j) / d;
                }
            }
		}
        void global_histogram_equalization() {
            int total = this->image.size();
            int n_bins = 256;

            vector<double> hist(n_bins, 0);
            for (int i = 0; i < total; i++) { hist[this->image.data[i]]++; }

            vector<double> cdf( hist );
            for (int i = 0; i < n_bins-1; i++) { cdf[i + 1] += cdf[i]; }

            double mincdf = 0.0;
            for (int i = 0; i < n_bins; i++) {
                if ( cdf[i] != 0 ) { mincdf = cdf[i]; break; }
            }

            vector<double> transfer_function( n_bins, 0 );
            for (int i = 0; i < n_bins; i++) {
                // transfer_function(i) = round(
                //     ((cdf(i) - mincdf) / total - mincdf) * (n_bins - 1)
                // );
                transfer_function[i] = (unsigned char)round(
                    (cdf[i]-mincdf)/(double)(total-mincdf)*(double)(n_bins-1)
                );
            }

            for (int i = 0; i < total; ++i) {
                this->image.data[i] = transfer_function[this->image.data[i]];
            }
        }
        void local_histogram_equalization(unsigned window_size) {
            int total = this->image.size();

            int half_size = (window_size/2);
            for ( int y = 0; y < this->image.height; y++ ) {
                for ( int x = 0; x < this->image.width; x++ ) {
                    double hist_sum = 0;
                    double scale = 0;
                    for ( int yr = y-half_size; yr <= y+half_size; yr++ ) {
                        for ( int xr = x-half_size; xr <= x+half_size; xr++ ) {
                            if ( yr < 0 || yr >= this->image.height ) { continue; }
                            if ( xr < 0 || xr >= this->image.width  ) { continue; }
                            scale++;

                            if ( this->image(0, x,y) < this->image(0, xr,yr) ) { 
                                continue;
                            }
                            hist_sum++; 
                        }
                    }
                    this->image(0, x, y) = (255/scale)*hist_sum;
                }
            }
        }
};

int main( int argc, char* argv[] ) {
    if ( argc == 2 ) {
        try {
			Solution D_1( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			D_1.process_intensity_dividing(2);
			D_1.output( "D_process_intensity_dividing_by_2.raw" );

			Solution D_2( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			D_2.process_intensity_dividing(2);
            D_2.global_histogram_equalization();
			D_2.output( "D_global_histogram_equalization.raw" );

			Solution D_3( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			D_3.process_intensity_dividing(2);
            D_3.local_histogram_equalization(51);
			D_3.output( "D_local_histogram_equalization.raw" );


			Solution E_1( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			E_1.process_intensity_dividing(3);
			E_1.output( "E_process_intensity_dividing_by_3.raw" );

			Solution E_2( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			E_2.process_intensity_dividing(3);
            E_2.global_histogram_equalization();
			E_2.output( "E_global_histogram_equalization.raw" );

			Solution E_3( argv[1], IMG_SIZE, IMG_SIZE, 1 );
			E_3.process_intensity_dividing(3);
            E_3.local_histogram_equalization(51);
			E_3.output( "E_local_histogram_equalization.raw" );
        } catch (const char err[]) {
            printf("%s\n", err);
        }   
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}
