#ifndef __BASIC_CPP
#define __BASIC_CPP

#include "basic.h"

using namespace std;

Basic::Basic(const char* filepath, unsigned height, unsigned width, unsigned pixelbyte) {
	this->image.resize(height, width, pixelbyte);

	FILE *file;
	if ( !(file = fopen(filepath, "rb")) ) {
		printf("Cannot open file!"); exit(1);
	}

	fread(&this->image.data[0], sizeof(unsigned char), this->image.size(), file);
	fclose(file);
}

void Basic::output( const char* filepath ) {
	FILE *file;
	if ( !(file = fopen( filepath, "wb")) ) {
		printf("Cannot open file!");
	}

	fwrite(&this->image.data[0], sizeof(unsigned char), this->image.size(), file);
	fclose(file);
}

// Parameter Constructor
template<typename T>
Image<T>::Image(unsigned height, unsigned width, unsigned pixelbyte) {
	resize(height * width * pixelbyte);
}

// None Parameter Constructor
template<typename T>
Image<T>::Image() {}

// (Virtual) Destructor
template<typename T>
Image<T>::~Image() {}

template<typename T>
void Image<T>::resize(unsigned height, unsigned width, unsigned pixelbyte) {
	this->data.resize(height * width * pixelbyte);
	this->height 	 = height;
	this->width  	 = width;
	this->pixelbyte  = pixelbyte;
}

template<typename T>
unsigned Image<T>::size() {
	return  this->height * this->width * this->pixelbyte;
}

// Access the individual elements
template<typename T>
T& Image<T>::operator()(const unsigned& p, const unsigned& h, const unsigned& w) {
  	return this->data[ p*this->height*this->width + h*this->width + w ];
}

#endif
