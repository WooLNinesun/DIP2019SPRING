#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256
#define PI 3.1415926535

class Solution : public Basic {
  public:
    Solution(const char *filepath, unsigned height, unsigned width)
        : Basic(filepath, height, width) {}

  public:
    vector<int> high_pass_filter_5{0, -1, 0, -1, 5, -1, 0, -1, 0};
    vector<int> high_pass_filter_9{-1, -1, -1, -1, 9, -1, -1, -1, -1};

  public:
    void generate_unsharp_masking(Matrix<unsigned char> &out, double c) {
        Matrix<unsigned char> low_pass(IMG_SIZE, IMG_SIZE);
        generate_low_pass_filter(low_pass, 2);

        Matrix<unsigned char> temp(IMG_SIZE, IMG_SIZE);
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                temp(i, j) =
                    (c * this->image(i, j) - (1 - c) * low_pass(i, j)) / (2 * c - 1);
            }
        }
        for (int i = 0; i < this->image.size(); i++) {
            out.data[i] = temp.data[i];
        }
    }
    void generate_low_pass_filter(Matrix<unsigned char> &out, double b) {
        double denominator = pow(b + 2, 2);
        double tmp1 = 1 / denominator;
        double tmp2 = tmp1 * b;
        double tmp3 = tmp2 * b;
        double filter[9] = {tmp1, tmp2, tmp1, tmp2, tmp3, tmp2, tmp1, tmp2, tmp1};

        Matrix<unsigned char> temp(IMG_SIZE, IMG_SIZE);
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                for (int k = i - 1, fi = 0; k <= i + 1; k++) {
                    int x = find_symmetry(k, IMG_SIZE);
                    for (int l = j - 1; l <= j + 1; l++, fi++) {
                        int y = find_symmetry(l, IMG_SIZE);
                        temp(i, j) += filter[fi] * this->image(x, y);
                    }
                }
            }
        }
        for (int i = 0; i < this->image.size(); i++) {
            out.data[i] = temp.data[i];
        }
    }
    void generate_high_pass_filter(Matrix<unsigned char> &out, int mask_num) {
        vector<int> mask;
        if (mask_num == 1) {
            mask = high_pass_filter_5;
        } else {
            mask = high_pass_filter_9;
        }

        Matrix<unsigned char> temp(IMG_SIZE, IMG_SIZE);
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                    int x = find_symmetry(k, IMG_SIZE);
                    for (int l = j - 1; l <= j + 1; l++, mi++) {
                        int y = find_symmetry(l, IMG_SIZE);
                        temp(i, j) += mask[mi] * this->image(x, y);
                    }
                }
            }
        }
        for (int i = 0; i < this->image.size(); i++) {
            out.data[i] = temp.data[i];
        }
    }
    void generate_warping(Matrix<unsigned char> &out) {
        Matrix<unsigned char> temp(IMG_SIZE, IMG_SIZE);
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                int x = i - IMG_SIZE / 2, y = j - IMG_SIZE / 2, r = IMG_SIZE / 2;
                double theta = -PI / 2 * (1 - sqrt(x * x + y * y) / 128);

                temp(i, j) = 255;
                if (x * x + y * y <= r * r) {
                    int u = get_u(x, y, theta), v = get_v(x, y, theta);
                    temp(i, j) = this->image(get_u(x, y, theta), get_v(x, y, theta));
                }
            }
        }
        for (int i = 0; i < this->image.size(); i++) {
            out.data[i] = temp.data[i];
        }
    }
    int get_u(int x, int y, double theta) {
        return cos(theta) * x + sin(theta) * y + IMG_SIZE / 2;
    }
    int get_v(int x, int y, double theta) {
        return cos(theta) * y - sin(theta) * x + IMG_SIZE / 2;
    }
};

int main(int argc, char *argv[]) {
    if (argc == 2) {
        try {
            Solution sample4(argv[1], IMG_SIZE, IMG_SIZE);

            sample4.generate_high_pass_filter(sample4.image, 1);
            sample4.output("sample4_high_pass_filter_5.raw");
            sample4.reset();
            sample4.generate_high_pass_filter(sample4.image, 2);
            sample4.output("sample4_high_pass_filter_9.raw");
            sample4.reset();
            sample4.generate_unsharp_masking(sample4.image, 4.0 / 5.0);
            sample4.output("sample4_unsharp_masking.raw");

            sample4.reset();
            sample4.generate_warping(sample4.image);
            sample4.output("sample4_warping.raw");
        } catch (const char err[]) {
            printf("%s\n", err);
        }
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}
