#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256
#define PI 3.1415926535

class Solution : public Basic {
  public:
    Solution(const char *filepath, unsigned height, unsigned width)
        : Basic(filepath, height, width) {}
    Solution() : Basic() {}

  public:
    vector<int> Prewitt_mask{
        -1, +0, +1, // row 1
        -1, +0, +1, // row 2
        -1, +0, +1, // row 3
        +1, +1, +1, // column 1
        +0, +0, +0, // column 2
        -1, -1, -1  // column 3
    };
    vector<int> Sobel_mask{
        -1, +0, +1, // row 1
        -2, +0, +2, // row 2
        -1, +0, +1, // row 3
        +1, +2, +1, // column 1
        +0, +0, +0, // column 2
        -1, -2, -1  // column 3
    };

    vector<int> four_neighbor_mask{
        +0, -1, +0, // line 1
        -1, +4, -1, // line 2
        +0, -1, +0, // line 3
    };

    vector<int> eight_neighbor_non_separable_mask{
        -1, -1, -1, // line 1
        -1, +8, -1, // line 2
        -1, -1, -1, // line 3
    };

    vector<int> eight_neighbor_separable_mask{
        -2, +1, -2, // line 1
        +1, +4, +1, // line 2
        -2, +1, -2, // line 3
    };

  public:
    void process_edge_detection_1st_order(int mask_k, int threshold) {
        Matrix<unsigned char> magnitude(IMG_SIZE, IMG_SIZE);
        Matrix<unsigned char> orientation(IMG_SIZE, IMG_SIZE);
        vector<int> mask((mask_k == 1) ? Prewitt_mask : Sobel_mask);
        generate_gradient(magnitude, orientation, mask);
        for (int i = 0; i < this->image.size(); i++) {
            if (threshold == -1) {
                this->image.data[i] = magnitude.data[i];
            } else {
                this->image.data[i] = (magnitude.data[i] > threshold) ? 255 : 0;
            }
        }
    }
    void process_edge_detection_2nd_order(double gaussian_sigma, int threshold,
                                          string index) {
        string msg_gaussian = "sample" + index + "_2nd_order_gaussian.raw";
        string msg_laplacian_NT = "sample" + index + "_2nd_order_laplacian_NT.raw";
        string msg_laplacian_T = "sample" + index + "_2nd_order_laplacian_T.raw";

        if (gaussian_sigma > 0) {
            Matrix<unsigned char> gaussian(IMG_SIZE, IMG_SIZE);
            generate_gaussian(gaussian, gaussian_sigma);
            for (int i = 0; i < this->image.size(); i++) {
                this->image.data[i] = gaussian.data[i];
            }
        }

        output(msg_gaussian.c_str());

        Matrix<int> laplacian(IMG_SIZE, IMG_SIZE);
        generate_laplacian(laplacian, four_neighbor_mask);
        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = laplacian.data[i] + 128;
        }

        output(msg_laplacian_NT.c_str());

        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = 255;
            if (abs(laplacian.data[i]) < threshold) {
                this->image.data[i] = 0;
            }
        }

        output(msg_laplacian_T.c_str());

        // Matrix<unsigned char> zero_crossing(IMG_SIZE, IMG_SIZE);
        // generate_zero_crossing(zero_crossing, laplacian, threshold);
        // for (int i = 0; i < this->image.size(); i++) {
        //     this->image.data[i] = zero_crossing.data[i];
        // }
    }
    void process_edge_detection_canny(double gaussian_sigma, int low_threshold,
                                      int high_threshold, string index) {

        string msg_gaussian = "sample" + index + "_canny_gaussian.raw";
        string msg_gradient = "sample" + index + "_canny_gradient.raw";
        string msg_suppression = "sample" + index + "_canny_suppression.raw";
        string msg_thresholding = "sample" + index + "_canny_thresholding.raw";

        Matrix<unsigned char> gaussian(IMG_SIZE, IMG_SIZE);
        generate_gaussian(gaussian, gaussian_sigma);
        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = gaussian.data[i];
        }

        output(msg_gaussian.c_str());

        Matrix<unsigned char> magnitude(IMG_SIZE, IMG_SIZE);
        Matrix<unsigned char> orientation(IMG_SIZE, IMG_SIZE);
        generate_gradient(magnitude, orientation, this->Sobel_mask);
        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = magnitude.data[i];
        }

        output(msg_gradient.c_str());

        Matrix<unsigned char> suppression(IMG_SIZE, IMG_SIZE);
        generate_non_maximal_suppression(suppression, orientation);
        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = suppression.data[i];
        }

        output(msg_suppression.c_str());

        for (int i = 0; i < this->image.size(); i++) {
            if (this->image.data[i] >= high_threshold) {
                this->image.data[i] = 255; // Edge Pixel
            } else if (this->image.data[i] < low_threshold) {
                this->image.data[i] = 0; // Non-Edge Pixel
            } else {
                this->image.data[i] = 128; // Candidate Pixel
            }
        }

        output(msg_thresholding.c_str());

        Matrix<unsigned char> connected(IMG_SIZE, IMG_SIZE);
        generate_connected_component(connected);
        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = connected.data[i];
        }
    }
    void generate_gradient(Matrix<unsigned char> &magnitude,
                           Matrix<unsigned char> &orientation, vector<int> mask) {
        int mask_k = mask[5];
        vector<int> r_mask(mask.begin(), mask.begin() + 9);
        vector<int> c_mask(mask.begin() + 9, mask.end());
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                double r_gradient = 0, c_gradient = 0;
                for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                    int x = find_symmetry(k, IMG_SIZE);
                    for (int l = j - 1; l <= j + 1; l++, mi++) {
                        int y = find_symmetry(l, IMG_SIZE);
                        r_gradient += r_mask[mi] * this->image(x, y);
                        c_gradient += c_mask[mi] * this->image(x, y);
                    }
                }

                r_gradient /= mask_k + 2, c_gradient /= mask_k + 2;

                magnitude(i, j) = sqrt(pow(r_gradient, 2.0) + pow(c_gradient, 2.0));
                orientation(i, j) = atan2(c_gradient, r_gradient) * 180 / PI;
                if (orientation(i, j) < 0) {
                    orientation(i, j) += 180.0;
                }
            }
        }
    }
    void generate_laplacian(Matrix<int> &out, vector<int> &mask) {
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                    int x = find_symmetry(k, IMG_SIZE);
                    for (int l = j - 1; l <= j + 1; l++, mi++) {
                        int y = find_symmetry(l, IMG_SIZE);
                        out(i, j) += mask[mi] * this->image(x, y);
                    }
                }
                out(i, j) /= mask[4];
            }
        }
    }
    void generate_zero_crossing(Matrix<unsigned char> &out, Matrix<int> &laplacian,
                                int threshold) {
        for (int i = 0; i < this->image.size(); i++) {
            if (abs(laplacian.data[i]) <= threshold) {
                laplacian.data[i] = 0;
            }
        }

        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                out(i, j) = 0;

                int i_l = find_symmetry(i - 1, IMG_SIZE);
                int i_r = find_symmetry(i + 1, IMG_SIZE);
                int j_l = find_symmetry(j - 1, IMG_SIZE);
                int j_r = find_symmetry(j + 1, IMG_SIZE);
                if (laplacian(i, j) * laplacian(i_r, j) < 0) {
                    out(i, j) = 255;
                }
                if (laplacian(i, j) * laplacian(i_r, j_r) < 0) {
                    out(i, j) = 255;
                }
                if (laplacian(i, j) * laplacian(i, j_r) < 0) {
                    out(i, j) = 255;
                }
                if (laplacian(i, j) == 0) {
                    if (laplacian(i_l, j) * laplacian(i_r, j) < 0) {
                        out(i, j) = 255;
                    }
                    if (laplacian(i, j_l) * laplacian(i, j_r) < 0) {
                        out(i, j) = 255;
                    }
                    if (laplacian(i_l, j_l) * laplacian(i_r, j_r) < 0) {
                        out(i, j) = 255;
                    }
                    if (laplacian(i_l, j_r) * laplacian(i_r, j_l) < 0) {
                        out(i, j) = 255;
                    }
                }
            }
        }
    }
    void generate_gaussian(Matrix<unsigned char> &out, double sigma) {
        vector<double> filter(25, 0);
        generate_gaussian_filter(filter, sigma);
        for (int i = 0; i < IMG_SIZE; i++) {
            for (int j = 0; j < IMG_SIZE; j++) {
                for (int k = i - 2, fi = 0; k <= i + 2; k++) {
                    int x = find_symmetry(k, IMG_SIZE);
                    for (int l = j - 2; l <= j + 2; l++, fi++) {
                        int y = find_symmetry(l, IMG_SIZE);
                        out(i, j) += filter[fi] * this->image(x, y);
                    }
                }
            }
        }
    }
    void generate_gaussian_filter(vector<double> &filter, double sigma) {
        // sum is for normalization
        double sum = 0.0;

        // generating 5x5 filter
        double s = 2.0 * sigma * sigma;
        for (int x = -2; x <= 2; x++) {
            for (int y = -2; y <= 2; y++) {
                double r = x * x + y * y, index = (x + 2) * 5 + (y + 2);
                filter[index] = (exp(-r / s)) / (PI * s);
                sum += filter[index];
            }
        }

        for (int i = 0; i < 25; i++) {
            filter[i] /= sum;
        }
    }
    void generate_non_maximal_suppression(Matrix<unsigned char> &out,
                                          Matrix<unsigned char> &orientation) {
        for (int i = 1; i < IMG_SIZE - 1; i++) {
            for (int j = 1; j < IMG_SIZE - 1; j++) {
                double angle = fmod(orientation(i, j) + 22.5, 180.0);
                int dx = 0, dy = 0;

                if (angle >= 0 && angle <= 45) {
                    dx = 0, dy = 1;
                } else if (angle > 45 && angle < 90) {
                    dx = 1, dy = -1;
                } else if (angle >= 90 && angle <= 135) {
                    dx = 1, dy = 0;
                } else if (angle > 135 && angle < 180) {
                    dx = 1, dy = 1;
                }

                if ((this->image(i, j) >= this->image(i + dx, j + dy)) &&
                    (this->image(i, j) >= this->image(i - dx, j - dy))) {
                    out(i, j) = this->image(i, j);
                } else {
                    out(i, j) = 0;
                }
            }
        }
    }
    void generate_connected_component(Matrix<unsigned char> &out) {
        out = this->image;
        for (int count = 0; count < 10; count++) {
            for (int i = 0; i < IMG_SIZE; i++) {
                for (int j = 0; j < IMG_SIZE; j++) {
                    if (out(i, j) == 255) {
                        for (int k = i - 1; k <= i + 1; k++) {
                            int x = find_symmetry(k, IMG_SIZE);
                            for (int l = j - 1; l <= j + 1; l++) {
                                int y = find_symmetry(l, IMG_SIZE);
                                if (out(x, y) == 128) {
                                    out(x, y) = 255;
                                }
                            }
                        }
                    }
                }
            }

            for (int i = IMG_SIZE - 1; i >= 0; i--) {
                for (int j = IMG_SIZE - 1; j >= 0; j--) {
                    if (out(i, j) == 255) {
                        for (int k = i - 1; k <= i + 1; k++) {
                            int x = find_symmetry(k, IMG_SIZE);
                            for (int l = j - 1; l <= j + 1; l++) {
                                int y = find_symmetry(l, IMG_SIZE);
                                if (out(x, y) == 128) {
                                    out(x, y) = 255;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (int i = 0; i < out.size(); i++) {
            if (out.data[i] == 128) {
                out.data[i] = 0;
            }
        }
    }
};

int main(int argc, char *argv[]) {
    if (argc == 4) {
        try {
            // smaple 1
            {
                Solution sample1(argv[1], IMG_SIZE, IMG_SIZE);

                sample1.process_edge_detection_1st_order(1, -1);
                sample1.output("sample1_1st_order_with_Prewitt_NT.raw");
                sample1.reset();
                sample1.process_edge_detection_1st_order(1, 27);
                sample1.output("sample1_1st_order_with_Prewitt_T.raw");
                sample1.reset();
                sample1.process_edge_detection_1st_order(2, -1);
                sample1.output("sample1_1st_order_with_Sobel_NT.raw");
                sample1.reset();
                sample1.process_edge_detection_1st_order(2, 28);
                sample1.output("sample1_1st_order_with_Sobel_T.raw");

                sample1.reset();
                sample1.process_edge_detection_2nd_order(1.4, 3, "1");
                sample1.output("sample1_2nd_order.raw");

                sample1.reset();
                sample1.process_edge_detection_canny(1.4, 8, 30, "1");
                sample1.output("sample1_canny.raw");
            }

            // smaple 2
            {
                Solution sample2(argv[2], IMG_SIZE, IMG_SIZE);

                sample2.process_edge_detection_1st_order(1, -1);
                sample2.output("sample2_1st_order_with_Prewitt_NT.raw");
                sample2.reset();
                sample2.process_edge_detection_1st_order(1, 32);
                sample2.output("sample2_1st_order_with_Prewitt_T.raw");
                sample2.reset();
                sample2.process_edge_detection_1st_order(2, -1);
                sample2.output("sample2_1st_order_with_Sobel_NT.raw");
                sample2.reset();
                sample2.process_edge_detection_1st_order(2, 33);
                sample2.output("sample2_1st_order_with_Sobel_T.raw");

                sample2.reset();
                sample2.process_edge_detection_2nd_order(1.4, 3, "2");
                sample2.output("sample2_2nd_order.raw");

                sample2.reset();
                sample2.process_edge_detection_canny(1.4, 8, 30, "2");
                sample2.output("sample2_canny.raw");
            }

            // smaple 3
            {
                Solution sample3(argv[3], IMG_SIZE, IMG_SIZE);

                sample3.process_edge_detection_1st_order(1, -1);
                sample3.output("sample3_1st_order_with_Prewitt_NT.raw");
                sample3.reset();
                sample3.process_edge_detection_1st_order(1, 39);
                sample3.output("sample3_1st_order_with_Prewitt_T.raw");
                sample3.reset();
                sample3.process_edge_detection_1st_order(2, -1);
                sample3.output("sample3_1st_order_with_Sobel_NT.raw");
                sample3.reset();
                sample3.process_edge_detection_1st_order(2, 40);
                sample3.output("sample3_1st_order_with_Sobel_T.raw");

                sample3.reset();
                sample3.process_edge_detection_2nd_order(1.4, 3, "3");
                sample3.output("sample3_2nd_order.raw");

                sample3.reset();
                sample3.process_edge_detection_canny(1.4, 8, 20, "3");
                sample3.output("sample3_canny.raw");
            }
        } catch (const char err[]) {
            printf("%s\n", err);
        }
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}
