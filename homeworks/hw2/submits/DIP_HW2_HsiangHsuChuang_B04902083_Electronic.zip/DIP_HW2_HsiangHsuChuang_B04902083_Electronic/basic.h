#include <cstdio>
#include <cstdlib>
#include <vector>

#ifndef __BASIC_H
#define __BASIC_H

using namespace std;

template <typename T>
class Matrix {
  public:
    vector<T> data;
    unsigned rows;
    unsigned cols;

  public:
    Matrix();
    Matrix(unsigned rows, unsigned cols);
    virtual ~Matrix();

  public:
    T &operator()(const unsigned &h, const unsigned &w);

  public:
    unsigned size();
    void resize(unsigned rows, unsigned cols, T init);
};

class Basic {
  public:
    Matrix<unsigned char> origin;
    Matrix<unsigned char> image;

  public:
    Basic();
    Basic(const char *filepath, unsigned height, unsigned width);

  public:
    void reset();
    void output(const char *filepath);

    int find_symmetry(int n, int bound);
};

#include "basic.cpp"

#endif
