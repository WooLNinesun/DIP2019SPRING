#ifndef __BASIC_CPP
#define __BASIC_CPP

#include "basic.h"

using namespace std;

Basic::Basic() {}
Basic::Basic(const char *filepath, unsigned height, unsigned width) {
    this->origin.resize(height, width, 0);

    FILE *file;
    if (!(file = fopen(filepath, "rb"))) {
        printf("Cannot open file!");
        exit(1);
    }

    fread(&this->origin.data[0], sizeof(unsigned char), this->origin.size(), file);
    fclose(file);

    this->image = this->origin;
}

void Basic::output(const char *filepath) {
    FILE *file;
    if (!(file = fopen(filepath, "wb"))) {
        printf("Cannot open file!");
    }

    fwrite(&this->image.data[0], sizeof(unsigned char), this->image.size(), file);
    fclose(file);
}

void Basic::reset() { this->image = this->origin; }

int Basic::find_symmetry(int n, int bound) {
    if (n < 0) {
        return -n;
    } else if (n >= bound) {
        return 2 * bound - n - 2;
    } else {
        return n;
    }
}

// Parameter Constructor
template <typename T>
Matrix<T>::Matrix(unsigned rows, unsigned cols) {
    resize(rows, cols, 0);
}

// None Parameter Constructor
template <typename T>
Matrix<T>::Matrix() {}

// (Virtual) Destructor
template <typename T>
Matrix<T>::~Matrix() {}

template <typename T>
void Matrix<T>::resize(unsigned rows, unsigned cols, T init) {
    this->data.resize(rows * cols, init);
    this->rows = rows, this->cols = cols;
}

template <typename T>
unsigned Matrix<T>::size() {
    return this->rows * this->cols;
}

// Access the individual elements
template <typename T>
T &Matrix<T>::operator()(const unsigned &i, const unsigned &j) {
    return this->data[i * this->cols + j];
}

#endif
