#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <string>
#include <time.h>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256
#define PI 3.1415926535

class Solution : public Basic {
  public:
    Solution(const char *filepath, unsigned height, unsigned width)
        : Basic(filepath, height, width) {}
    Solution() : Basic() {}

  public:
    // Digital Image processing, 3rd Edition, Table 14.3-1, pp.413,414
    // Shrink, Thin, and Skeletonize Conditional Mark Patterns [M = 1 if hit]
    // the value which represents black in the binary image
    static const unsigned char I = 255;
    static const vector<int> S_conditional_patterns_indeies;
    static const vector<int> T_conditional_patterns_indeies;
    static const vector<int> K_conditional_patterns_indeies;
    static const vector<vector<vector<unsigned char>>> conditional_patterns;

    // Digital Image processing, 3rd Edition, Table 14.3-I, p. 414
    // Shrink, Thin, and Skeletonize Unconditional Mark Patterns
    // P(M,M0,M1,M2,M3,M4,M5,M6,M7) = 1 if hit]

    // A ∪ B ∪ C = 1, A ∪ B = 1, D = 0 ∪ 1
    static const unsigned char M = 1;
    static const unsigned char A = 2;
    static const unsigned char B = 3;
    static const unsigned char C = 4;
    static const unsigned char D = 5;
    static const vector<vector<unsigned char>> ST_unconditional_patterns;
    static const vector<vector<unsigned char>> K_unconditional_patterns;

    Solution &Dilation(Matrix<unsigned char> &out, vector<bool> H) {
        Matrix<unsigned char> temp(this->image.rows + 2, this->image.cols + 2, 0);

        for (int i = 0, hi = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++, hi++) {
                if (H[hi] == 1) {
                    for (int k = 0; k < this->image.rows; k++) {
                        for (int l = 0; l < this->image.cols; l++) {
                            temp(k + i, l + j) |= this->image(k, l);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                out(i, j) = temp(i + 1, j + 1);
            }
        }
        return *this;
    }

    Solution &Erosion(Matrix<unsigned char> &out, vector<bool> H) {
        Matrix<unsigned char> temp(this->image.rows + 2, this->image.cols + 2, 255);

        for (int i = 0, hi = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++, hi++) {
                if (H[hi] == 1) {
                    for (int k = 0; k < this->image.rows; k++) {
                        for (int l = 0; l < this->image.cols; l++) {
                            temp(k + i, l + j) &= this->image(k, l);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                out(i, j) = temp(i + 1, j + 1);
            }
        }
        return *this;
    }

    Solution &boundary_extraction() {
        Matrix<unsigned char> temp(this->image.rows, this->image.cols);
        Erosion(temp, {1, 1, 1, 1, 1, 1, 1, 1, 1});
        this->image = this->image - temp;
        return *this;
    }

    struct Coordinate {
        int x, y;
        Coordinate(int paramx, int paramy) : x(paramx), y(paramy) {}
    };

    void BFS(Matrix<unsigned char> &out, Coordinate Coord, unsigned char color) {
        queue<Coordinate> visit_queue;
        visit_queue.push(Coord);
        while (!visit_queue.empty()) {
            Coordinate now = visit_queue.front();
            visit_queue.pop();
            for (int i = now.x - 1; i <= now.x + 1; i++) {
                int x = symmetry(i, this->image.rows);
                for (int j = now.y - 1; j <= now.y + 1; j++) {
                    int y = symmetry(j, this->image.cols);
                    if (out(x, y) == 255) {
                        out(x, y) = color;
                        visit_queue.push(Coordinate(i, j));
                    }
                }
            }
        }
    }

    Solution &connected_component_labeling() {
        srand(time(NULL));

        Matrix<unsigned char> temp(this->image);
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                if (temp(i, j) == 255) {
                    // make color range in [75, 180]
                    unsigned char color = (rand() % (256 - 150)) + 75;
                    BFS(temp, Coordinate(i, j), color);
                }
            }
        }

        this->image = temp;

        return *this;
    }

    void mark_conditional(Matrix<unsigned char> &out,
                          vector<vector<unsigned char>> &table) {
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                vector<unsigned char> pixel_stack;
                for (int k = i - 1; k <= i + 1; k++) {
                    int x = symmetry(k, this->image.rows);
                    for (int l = j - 1; l <= j + 1; l++) {
                        int y = symmetry(l, this->image.cols);
                        pixel_stack.push_back(this->image(x, y));
                    }
                }
                for (int it = 0; it < table.size(); it++) {
                    if (table[it] == pixel_stack) {
                        out(i, j) = M;
                        break;
                    }
                }
            }
        }
    }

    bool match_unconditional(vector<unsigned char> &pixel_stack,
                             vector<unsigned char> &pattern) {
        bool have_ab = false, have_c = false;
        bool a = false, b = false, c = false;
        for (int i = 0; i < pattern.size(); i++) {
            switch (pattern[i]) {
            case 0:
                if (pixel_stack[i] == M) {
                    return false;
                }
                break;
            case Solution::M:
                if (pixel_stack[i] == 0) {
                    return false;
                }
                break;
            case Solution::A:
                if (pixel_stack[i] == M) {
                    a = true;
                } else {
                    have_ab = true;
                }
                break;
            case Solution::B:
                if (pixel_stack[i] == M) {
                    b = true;
                } else {
                    have_ab = true;
                }
                break;
            case Solution::C:
                if (pixel_stack[i] == M) {
                    c = true;
                } else {
                    have_c = true;
                }
                break;
            case Solution::D:
                break;
            default:
                break;
            }
        }

        if (have_c == true) {
            return a || b || c;
        }
        if (have_ab == true) {
            return a || b;
        }
        return true;
    }

    void mark_unconditional(Matrix<unsigned char> &out,
                            vector<vector<unsigned char>> patterns) {
        Matrix<unsigned char> conditional(out);
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                if (conditional(i, j) == 0) {
                    continue;
                }
                vector<unsigned char> pixel_stack;
                for (int k = i - 1; k <= i + 1; k++) {
                    int x = symmetry(k, this->image.rows);
                    for (int l = j - 1; l <= j + 1; l++) {
                        int y = symmetry(l, this->image.cols);
                        pixel_stack.push_back(conditional(x, y));
                    }
                }
                vector<vector<unsigned char>>::iterator it;
                for (it = patterns.begin(); it != patterns.end(); it++) {
                    if (match_unconditional(pixel_stack, *it)) {
                        out(i, j) = 0;
                        break;
                    }
                }
            }
        }
    }
    Solution &shrinking() {
        vector<vector<unsigned char>> table;
        vector<int> indeies = S_conditional_patterns_indeies;
        for (vector<int>::iterator it = indeies.begin(); it != indeies.end(); it++) {
            vector<vector<unsigned char>> patterns = this->conditional_patterns[*it];
            table.insert(table.end(), patterns.begin(), patterns.end());
        }

        size_t erasure_count;
        do {
            erasure_count = 0;
            Matrix<unsigned char> conditional(this->image.rows, this->image.cols);
            mark_conditional(conditional, table);
            mark_unconditional(conditional, ST_unconditional_patterns);
            for (int i = 0; i < this->image.size(); i++) {
                if (conditional(i) == M) {
                    this->image(i) = 0;
                    erasure_count++;
                }
            }
        } while (erasure_count > 0);

        return *this;
    }
    Solution &thinning() {
        vector<vector<unsigned char>> table;
        vector<int> indeies = T_conditional_patterns_indeies;
        for (vector<int>::iterator it = indeies.begin(); it != indeies.end(); it++) {
            vector<vector<unsigned char>> patterns = this->conditional_patterns[*it];
            table.insert(table.end(), patterns.begin(), patterns.end());
        }

        size_t erasure_count;
        do {
            erasure_count = 0;
            Matrix<unsigned char> conditional(this->image.rows, this->image.cols);
            mark_conditional(conditional, table);
            mark_unconditional(conditional, ST_unconditional_patterns);
            for (int i = 0; i < this->image.size(); i++) {
                if (conditional(i) == M) {
                    this->image(i) = 0;
                    erasure_count++;
                }
            }
        } while (erasure_count > 0);

        return *this;
    }
    Solution &skeletonizing() {
        vector<vector<unsigned char>> table;
        vector<int> indeies = K_conditional_patterns_indeies;
        for (vector<int>::iterator it = indeies.begin(); it != indeies.end(); it++) {
            vector<vector<unsigned char>> patterns = this->conditional_patterns[*it];
            table.insert(table.end(), patterns.begin(), patterns.end());
        }

        size_t erasure_count;
        do {
            erasure_count = 0;
            Matrix<unsigned char> conditional(this->image.rows, this->image.cols);
            mark_conditional(conditional, table);
            mark_unconditional(conditional, K_unconditional_patterns);
            for (int i = 0; i < this->image.size(); i++) {
                if (conditional(i) == M) {
                    this->image(i) = 0;
                    erasure_count++;
                }
            }
        } while (erasure_count > 0);

        return *this;
    }
};

int main(int argc, char *argv[]) {
    if (argc == 2) {
        try {
            Solution sample(argv[1], IMG_SIZE, IMG_SIZE);

            sample.boundary_extraction().output("B.raw").reset();

            sample.connected_component_labeling().output("C.raw").reset();

            sample.thinning().output("D_1.raw").reset();
            sample.skeletonizing().output("D_2.raw").reset();

        } catch (const char err[]) {
            printf("%s\n", err);
        }
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}

const vector<int> Solution::S_conditional_patterns_indeies = {0, 1, 2,  4,  5, 7,
                                                              8, 9, 10, 11, 12};
const vector<int> Solution::T_conditional_patterns_indeies = {3, 4,  5,  6, 8,
                                                              9, 10, 11, 12};
const vector<int> Solution::K_conditional_patterns_indeies = {3,  4,  8,  9,
                                                              10, 11, 12, 13};

const vector<vector<vector<unsigned char>>> Solution::conditional_patterns = {
    {// S 1
     {0, 0, I, /**/ 0, I, 0, /**/ 0, 0, 0},
     {I, 0, 0, /**/ 0, I, 0, /**/ 0, 0, 0},
     {0, 0, 0, /**/ 0, I, 0, /**/ I, 0, 0},
     {0, 0, 0, /**/ 0, I, 0, /**/ 0, 0, I}},
    {// S 2
     {0, 0, 0, /**/ 0, I, I, /**/ 0, 0, 0},
     {0, I, 0, /**/ 0, I, 0, /**/ 0, 0, 0},
     {0, 0, 0, /**/ I, I, 0, /**/ 0, 0, 0},
     {0, 0, 0, /**/ 0, I, 0, /**/ 0, I, 0}},
    {// S 3
     {0, 0, I, /**/ 0, I, I, /**/ 0, 0, 0},
     {0, I, I, /**/ 0, I, 0, /**/ 0, 0, 0},
     {I, I, 0, /**/ 0, I, 0, /**/ 0, 0, 0},
     {I, 0, 0, /**/ I, I, 0, /**/ 0, 0, 0},
     {0, 0, 0, /**/ I, I, 0, /**/ I, 0, 0},
     {0, 0, 0, /**/ 0, I, 0, /**/ I, I, 0},
     {0, 0, 0, /**/ 0, I, 0, /**/ 0, I, I},
     {0, 0, 0, /**/ 0, I, I, /**/ 0, 0, I}},
    {// TK 4
     {0, I, 0, /**/ 0, I, I, /**/ 0, 0, 0},
     {0, I, 0, /**/ I, I, 0, /**/ 0, 0, 0},
     {0, 0, 0, /**/ I, I, 0, /**/ 0, I, 0},
     {0, 0, 0, /**/ 0, I, I, /**/ 0, I, 0}},
    {// STK 4
     {0, 0, I, /**/ 0, I, I, /**/ 0, 0, I},
     {I, I, I, /**/ 0, I, 0, /**/ 0, 0, 0},
     {I, 0, 0, /**/ I, I, 0, /**/ I, 0, 0},
     {0, 0, 0, /**/ 0, I, 0, /**/ I, I, I}},
    {// ST 5
     {I, I, 0, /**/ 0, I, I, /**/ 0, 0, 0},
     {0, I, 0, /**/ 0, I, I, /**/ 0, 0, I},
     {0, I, I, /**/ I, I, 0, /**/ 0, 0, 0},
     {0, 0, I, /**/ 0, I, I, /**/ 0, I, 0}},
    {// ST 5
     {0, I, I, /**/ 0, I, I, /**/ 0, 0, 0},
     {I, I, 0, /**/ I, I, 0, /**/ 0, 0, 0},
     {0, 0, 0, /**/ I, I, 0, /**/ I, I, 0},
     {0, 0, 0, /**/ 0, I, I, /**/ 0, I, I}},
    {// ST 6
     {I, I, 0, /**/ 0, I, I, /**/ 0, 0, I},
     {0, I, I, /**/ I, I, 0, /**/ I, 0, 0}},
    {// STK 6
     {I, I, I, /**/ 0, I, I, /**/ 0, 0, 0},
     {0, I, I, /**/ 0, I, I, /**/ 0, 0, I},
     {I, I, I, /**/ I, I, 0, /**/ 0, 0, 0},
     {I, I, 0, /**/ I, I, 0, /**/ I, 0, 0},
     {I, 0, 0, /**/ I, I, 0, /**/ I, I, 0},
     {0, 0, 0, /**/ I, I, 0, /**/ I, I, I},
     {0, 0, 0, /**/ 0, I, I, /**/ I, I, I},
     {0, 0, I, /**/ 0, I, I, /**/ 0, I, I}},
    {// STK 7
     {I, I, I, /**/ 0, I, I, /**/ 0, 0, I},
     {I, I, I, /**/ I, I, 0, /**/ I, 0, 0},
     {I, 0, 0, /**/ I, I, 0, /**/ I, I, I},
     {0, 0, I, /**/ 0, I, I, /**/ I, I, I}},
    {// STK 8
     {0, I, I, /**/ 0, I, I, /**/ 0, I, I},
     {I, I, I, /**/ I, I, I, /**/ 0, 0, 0},
     {I, I, 0, /**/ I, I, 0, /**/ I, I, 0},
     {0, 0, 0, /**/ I, I, I, /**/ I, I, I}},
    {// STK 9
     {I, I, I, /**/ 0, I, I, /**/ 0, I, I},
     {0, I, I, /**/ 0, I, I, /**/ I, I, I},
     {I, I, I, /**/ I, I, I, /**/ I, 0, 0},
     {I, I, I, /**/ I, I, I, /**/ 0, 0, I},
     {I, I, I, /**/ I, I, 0, /**/ I, I, 0},
     {I, I, 0, /**/ I, I, 0, /**/ I, I, I},
     {I, 0, 0, /**/ I, I, I, /**/ I, I, I},
     {0, 0, I, /**/ I, I, I, /**/ I, I, I}},
    {// STK 10
     {I, I, I, /**/ 0, I, I, /**/ I, I, I},
     {I, I, I, /**/ I, I, I, /**/ I, 0, I},
     {I, I, I, /**/ I, I, 0, /**/ I, I, I},
     {I, 0, I, /**/ I, I, I, /**/ I, I, I}},
    {// K 11
     {I, I, I, /**/ I, I, I, /**/ 0, I, I},
     {I, I, I, /**/ I, I, I, /**/ I, I, 0},
     {I, I, 0, /**/ I, I, I, /**/ I, I, I},
     {0, I, I, /**/ I, I, I, /**/ I, I, I}},
};
const vector<vector<unsigned char>> Solution::ST_unconditional_patterns = {
    // spur
    {0, 0, M, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, 0, 0, /**/ 0, M, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ 0, M, 0, /**/ 0, M, 0},
    {0, 0, 0, /**/ 0, M, M, /**/ 0, 0, 0},
    // L Cluster
    {0, 0, M, /**/ 0, M, M, /**/ 0, 0, 0},
    {0, M, M, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, M, 0, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, 0, 0, /**/ M, M, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ M, M, 0, /**/ M, 0, 0},
    {0, 0, 0, /**/ 0, M, 0, /**/ M, M, 0},
    {0, 0, 0, /**/ 0, M, 0, /**/ 0, M, M},
    {0, 0, 0, /**/ 0, M, M, /**/ 0, 0, M},
    // offset
    {0, M, M, /**/ M, M, 0, /**/ 0, 0, 0},
    {M, M, 0, /**/ 0, M, M, /**/ 0, 0, 0},
    {0, M, 0, /**/ 0, M, M, /**/ 0, 0, M},
    {0, 0, M, /**/ 0, M, M, /**/ 0, M, 0},
    // spur corner
    {0, A, M, /**/ 0, M, B, /**/ M, 0, 0},
    {M, B, 0, /**/ A, M, 0, /**/ 0, 0, M},
    {0, 0, M, /**/ A, M, 0, /**/ M, B, 0},
    {M, 0, 0, /**/ 0, M, B, /**/ 0, A, M},
    // corner clutter
    {M, M, D, /**/ M, M, D, /**/ D, D, D},
    // tee branch
    {D, M, 0, /**/ M, M, M, /**/ D, 0, 0},
    {0, M, D, /**/ M, M, M, /**/ 0, 0, D},
    {0, 0, D, /**/ M, M, M, /**/ 0, M, D},
    {D, 0, 0, /**/ M, M, M, /**/ D, M, 0},
    {D, M, D, /**/ M, M, 0, /**/ 0, M, 0},
    {0, M, 0, /**/ M, M, 0, /**/ D, M, D},
    {0, M, 0, /**/ 0, M, M, /**/ D, M, D},
    {D, M, D, /**/ 0, M, M, /**/ 0, M, 0},
    // vee branch
    {M, D, M, /**/ D, M, D, /**/ A, B, C},
    {M, D, C, /**/ D, M, B, /**/ M, D, A},
    {C, B, A, /**/ D, M, D, /**/ M, D, M},
    {A, D, M, /**/ B, M, D, /**/ C, D, M},
    // diagonal branch
    {D, M, 0, /**/ 0, M, M, /**/ M, 0, D},
    {0, M, D, /**/ M, M, 0, /**/ D, 0, M},
    {D, 0, M, /**/ M, M, 0, /**/ 0, M, D},
    {M, 0, D, /**/ 0, M, M, /**/ D, M, 0},
};
const vector<vector<unsigned char>> Solution::K_unconditional_patterns = {
    // spur
    {0, 0, 0, /**/ 0, M, 0, /**/ 0, 0, M},
    {0, 0, 0, /**/ 0, M, 0, /**/ M, 0, 0},
    {0, 0, M, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, 0, 0, /**/ 0, M, 0, /**/ 0, 0, 0},
    // single 4-connection
    {0, 0, 0, /**/ 0, M, 0, /**/ 0, M, 0},
    {0, 0, 0, /**/ 0, M, M, /**/ 0, 0, 0},
    {0, 0, 0, /**/ M, M, 0, /**/ 0, 0, 0},
    {0, M, 0, /**/ 0, M, 0, /**/ 0, 0, 0},
    // L corner
    {0, M, 0, /**/ 0, M, M, /**/ 0, 0, 0},
    {0, M, 0, /**/ M, M, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ 0, M, M, /**/ 0, M, 0},
    {0, 0, 0, /**/ M, M, 0, /**/ 0, M, 0},
    // corner cluster
    {D, M, M, /**/ D, M, M, /**/ D, D, D},
    {D, D, D, /**/ M, M, D, /**/ M, M, D},
    {M, M, D, /**/ M, M, D, /**/ D, D, D},
    {D, D, D, /**/ D, M, M, /**/ D, M, M},
    // tee branch
    {D, M, D, /**/ M, M, M, /**/ D, 0, 0},
    {D, M, D, /**/ M, M, D, /**/ D, M, D},
    {D, D, D, /**/ M, M, M, /**/ D, M, D},
    {D, M, D, /**/ D, M, M, /**/ D, M, D},
    // vee branch
    {M, D, M, /**/ D, M, D, /**/ A, B, C},
    {M, D, C, /**/ D, M, B, /**/ M, D, A},
    {C, B, A, /**/ D, M, D, /**/ M, D, M},
    {A, D, M, /**/ B, M, D, /**/ C, D, M},
    // diagonal branch
    {D, M, 0, /**/ 0, M, M, /**/ M, 0, D},
    {0, M, D, /**/ M, M, 0, /**/ D, 0, M},
    {D, 0, M, /**/ M, M, 0, /**/ 0, M, D},
    {M, 0, D, /**/ 0, M, M, /**/ D, M, 0},
};
