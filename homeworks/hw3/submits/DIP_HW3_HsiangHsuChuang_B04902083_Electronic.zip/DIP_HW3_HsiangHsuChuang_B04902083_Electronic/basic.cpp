#include <cmath>
#include <string>
#include <vector>

#ifndef __BASIC_CPP
#define __BASIC_CPP

#include "basic.h"

using namespace std;

const vector<int> Basic::Prewitt_mask{
    -1, +0, +1, // row 1
    -1, +0, +1, // row 2
    -1, +0, +1, // row 3
    +1, +1, +1, // column 1
    +0, +0, +0, // column 2
    -1, -1, -1  // column 3
};
const vector<int> Basic::Sobel_mask{
    -1, +0, +1, // row 1
    -2, +0, +2, // row 2
    -1, +0, +1, // row 3
    +1, +2, +1, // column 1
    +0, +0, +0, // column 2
    -1, -2, -1  // column 3
};

const vector<int> Basic::four_neighbor_mask{
    +0, -1, +0, // line 1
    -1, +4, -1, // line 2
    +0, -1, +0, // line 3
};

const vector<int> Basic::eight_neighbor_non_separable_mask{
    -1, -1, -1, // line 1
    -1, +8, -1, // line 2
    -1, -1, -1, // line 3
};

const vector<int> Basic::eight_neighbor_separable_mask{
    -2, +1, -2, // line 1
    +1, +4, +1, // line 2
    -2, +1, -2, // line 3
};
const vector<int> Basic::high_pass_filter_9{
    -1, -1, -1, // line 1
    -1, +9, -1, // line 2
    -1, -1, -1  // line 3
};
const vector<int> Basic::high_pass_filter_5{
    +0, -1, +0, // line 1
    -1, +5, -1, // line 2
    +0, -1, +0  // line 3
};

Basic::Basic() {}
Basic::Basic(const char *filepath, unsigned height, unsigned width) {
    this->origin.resize(height, width, 0);

    FILE *file;
    if (!(file = fopen(filepath, "rb"))) {
        printf("Cannot open file!");
        exit(1);
    }

    fread(&this->origin(0), sizeof(unsigned char), this->origin.size(), file);
    fclose(file);

    this->image = this->origin;
}

Basic &Basic::output(const char *filepath) {
    FILE *file;
    if (!(file = fopen(filepath, "wb"))) {
        printf("Cannot open file!");
    }

    fwrite(&this->image(0), sizeof(unsigned char), this->image.size(), file);
    fclose(file);

    return *this;
}

Basic &Basic::reset() {
    this->image = this->origin;
    return *this;
}

int Basic::symmetry(int n, int bound) {
    if (n < 0) {
        return -n;
    } else if (n >= bound) {
        return 2 * bound - n - 2;
    } else {
        return n;
    }
}

Basic &Basic::horizontal_flipping() {
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols / 2; j++) {
            swap(this->image(i, j), this->image(i, 255 - j));
        }
    }

    return *this;
}

Basic &Basic::power_law(double p) {
    unsigned c = 1;
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            double pixel = (double)this->image(i, j);
            this->image(i, j) = c * pow(pixel / 255.0, p) * 255;
        }
    }
    return *this;
}

Basic &Basic::intensity_dividing(unsigned d) {
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            this->image(i, j) = this->image(i, j) / d;
        }
    }
    return *this;
}

Basic &Basic::global_equalize_hist() {
    int total = this->image.size();
    int n_bins = 256;

    vector<double> hist(n_bins, 0);
    for (int i = 0; i < total; i++) {
        hist[this->image(i)]++;
    }

    vector<double> cdf(hist);
    for (int i = 0; i < n_bins - 1; i++) {
        cdf[i + 1] += cdf[i];
    }

    double mincdf = 0.0;
    for (int i = 0; i < n_bins; i++) {
        if (cdf[i] != 0) {
            mincdf = cdf[i];
            break;
        }
    }

    vector<double> transfer_function(n_bins, 0);
    for (int i = 0; i < n_bins; i++) {
        // transfer_function(i) = round(
        //     ((cdf(i) - mincdf) / total - mincdf) * (n_bins - 1)
        // );
        transfer_function[i] = (unsigned char)round(
            (cdf[i] - mincdf) / (double)(total - mincdf) * (double)(n_bins - 1));
    }

    for (int i = 0; i < total; ++i) {
        this->image(i) = transfer_function[this->image(i)];
    }

    return *this;
}

Basic &Basic::local_equalize_hist(unsigned window_size) {
    int total = this->image.size();

    int half_size = (window_size / 2);
    for (int y = 0; y < this->image.rows; y++) {
        for (int x = 0; x < this->image.cols; x++) {
            double hist_sum = 0;
            double scale = 0;
            for (int yr = y - half_size; yr <= y + half_size; yr++) {
                for (int xr = x - half_size; xr <= x + half_size; xr++) {
                    if (yr < 0 || yr >= this->image.rows) {
                        continue;
                    }
                    if (xr < 0 || xr >= this->image.cols) {
                        continue;
                    }
                    scale++;

                    if (this->image(x, y) < this->image(xr, yr)) {
                        continue;
                    }
                    hist_sum++;
                }
            }
            this->image(x, y) = (255 / scale) * hist_sum;
        }
    }

    return *this;
}

Basic &Basic::low_pass_filter(double b) {
    double denominator = pow(b + 2, 2);
    double tmp1 = 1 / denominator;
    double tmp2 = tmp1 * b;
    double tmp3 = tmp2 * b;
    double filter[9] = {tmp1, tmp2, tmp1, tmp2, tmp3, tmp2, tmp1, tmp2, tmp1};

    Matrix<unsigned char> temp(this->image.rows, this->image.cols);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            for (int k = i - 1, fi = 0; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++, fi++) {
                    int y = symmetry(l, this->image.cols);
                    temp(i, j) += filter[fi] * this->image(x, y);
                }
            }
        }
    }
    for (int i = 0; i < this->image.size(); i++) {
        this->image(i) = temp(i);
    }

    return *this;
}

Basic &Basic::low_pass_filter(Matrix<unsigned char> &out, double b) {
    double denominator = pow(b + 2, 2);
    double tmp1 = 1 / denominator;
    double tmp2 = tmp1 * b;
    double tmp3 = tmp2 * b;
    double filter[9] = {tmp1, tmp2, tmp1, tmp2, tmp3, tmp2, tmp1, tmp2, tmp1};

    Matrix<unsigned char> temp(this->image.rows, this->image.cols);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            for (int k = i - 1, fi = 0; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++, fi++) {
                    int y = symmetry(l, this->image.cols);
                    temp(i, j) += filter[fi] * this->image(x, y);
                }
            }
        }
    }
    for (int i = 0; i < this->image.size(); i++) {
        out(i) = temp(i);
    }

    return *this;
}

Basic &Basic::high_pass_filter(int mask_num) {
    vector<int> mask;
    if (mask_num == 1) {
        mask = high_pass_filter_5;
    } else {
        mask = high_pass_filter_9;
    }

    Matrix<unsigned char> temp(this->image.rows, this->image.cols);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++, mi++) {
                    int y = symmetry(l, this->image.cols);
                    temp(i, j) += mask[mi] * this->image(x, y);
                }
            }
        }
    }
    for (int i = 0; i < this->image.size(); i++) {
        this->image(i) = temp(i);
    }

    return *this;
}

Basic &Basic::high_pass_filter(Matrix<unsigned char> &out, int mask_num) {
    vector<int> mask;
    if (mask_num == 1) {
        mask = high_pass_filter_5;
    } else {
        mask = high_pass_filter_9;
    }

    Matrix<unsigned char> temp(this->image.rows, this->image.cols);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++, mi++) {
                    int y = symmetry(l, this->image.cols);
                    temp(i, j) += mask[mi] * this->image(x, y);
                }
            }
        }
    }
    for (int i = 0; i < out.size(); i++) {
        out(i) = temp(i);
    }

    return *this;
}

Basic &Basic::outlier_detection(double e) {
    vector<unsigned char> temp(this->image.size(), 0);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            double sum = 0;
            for (int k = i - 1; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++) {
                    int y = symmetry(l, this->image.cols);
                    if (k == i, l == j) {
                        continue;
                    }
                    sum += this->image(x, y);
                }
            }
            temp[i * this->image.cols + j] = sum / 8.0;
        }
    }
    for (int i = 0; i < this->image.size(); i++) {
        if (abs(this->image(i) - temp[i]) > e) {
            this->image(i) = temp[i];
        }
    }

    return *this;
}

Basic &Basic::median_filtering() {
    vector<unsigned char> temp(this->image.size(), 0);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            vector<unsigned char> median;
            for (int k = i - 1; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++) {
                    int y = symmetry(l, this->image.cols);
                    median.push_back(this->image(x, y));
                }
            }
            sort(median.begin(), median.end());
            temp[i * this->image.cols + j] = median[4];
        }
    }
    for (int i = 0; i < this->image.size(); i++) {
        this->image(i) = temp[i];
    }

    return *this;
}

double Basic::computer_mse(const vector<unsigned char> &a) {
    double total = 0;
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            total += pow(a[i * this->image.cols + j] - this->image(i, j), 2);
        }
    }
    return total / (this->image.size());
}

double Basic::computer_psnr(const vector<unsigned char> &a) {
    return 10 * log10(255 * 255 / computer_mse(a));
}

Basic &Basic::process_edge_detection_1st_order(int mask_k, int threshold) {
    Matrix<unsigned char> magnitude(this->image.rows, this->image.cols);
    Matrix<unsigned char> orientation(this->image.rows, this->image.cols);
    vector<int> mask((mask_k == 1) ? Basic::Prewitt_mask : Basic::Sobel_mask);
    generate_gradient(magnitude, orientation, mask);
    for (int i = 0; i < this->image.size(); i++) {
        if (threshold == -1) {
            this->image.data[i] = magnitude.data[i];
        } else {
            this->image.data[i] = (magnitude.data[i] > threshold) ? 255 : 0;
        }
    }

    return *this;
}

Basic &Basic::process_edge_detection_2nd_order(double gaussian_sigma, int threshold) {
    if (gaussian_sigma > 0) {
        Matrix<unsigned char> gaussian(this->image.rows, this->image.cols);
        generate_gaussian(gaussian, gaussian_sigma);
        for (int i = 0; i < this->image.size(); i++) {
            this->image.data[i] = gaussian.data[i];
        }
    }

    Matrix<int> laplacian(this->image.rows, this->image.cols);
    generate_laplacian(laplacian, Basic::four_neighbor_mask);
    for (int i = 0; i < this->image.size(); i++) {
        this->image.data[i] = laplacian.data[i] + 128;
    }

    for (int i = 0; i < this->image.size(); i++) {
        this->image.data[i] = 255;
        if (abs(laplacian.data[i]) < threshold) {
            this->image.data[i] = 0;
        }
    }

    // Matrix<unsigned char> zero_crossing(this->image.rows, this->image.cols);
    // generate_zero_crossing(zero_crossing, laplacian, threshold);
    // for (int i = 0; i < this->image.size(); i++) {
    //     this->image.data[i] = zero_crossing.data[i];
    // }
    return *this;
}

Basic &Basic::process_edge_detection_canny(double gaussian_sigma, int low_threshold,
                                           int high_threshold) {

    Matrix<unsigned char> gaussian(this->image.rows, this->image.cols);
    generate_gaussian(gaussian, gaussian_sigma);
    for (int i = 0; i < this->image.size(); i++) {
        this->image.data[i] = gaussian.data[i];
    }

    Matrix<unsigned char> magnitude(this->image.rows, this->image.cols);
    Matrix<unsigned char> orientation(this->image.rows, this->image.cols);
    generate_gradient(magnitude, orientation, Sobel_mask);
    for (int i = 0; i < this->image.size(); i++) {
        this->image.data[i] = magnitude.data[i];
    }

    Matrix<unsigned char> suppression(this->image.rows, this->image.cols);
    generate_non_maximal_suppression(suppression, orientation);
    for (int i = 0; i < this->image.size(); i++) {
        this->image.data[i] = suppression.data[i];
    }

    for (int i = 0; i < this->image.size(); i++) {
        if (this->image.data[i] >= high_threshold) {
            this->image.data[i] = 255; // Edge Pixel
        } else if (this->image.data[i] < low_threshold) {
            this->image.data[i] = 0; // Non-Edge Pixel
        } else {
            this->image.data[i] = 128; // Candidate Pixel
        }
    }

    Matrix<unsigned char> connected(this->image.rows, this->image.cols);
    generate_connected_component(connected);
    for (int i = 0; i < this->image.size(); i++) {
        this->image.data[i] = connected.data[i];
    }

    return *this;
}

Basic &Basic::generate_gradient(Matrix<unsigned char> &magnitude,
                                Matrix<unsigned char> &orientation, vector<int> mask) {
    int mask_k = mask[5];
    vector<int> r_mask(mask.begin(), mask.begin() + 9);
    vector<int> c_mask(mask.begin() + 9, mask.end());
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            double r_gradient = 0, c_gradient = 0;
            for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++, mi++) {
                    int y = symmetry(l, this->image.cols);
                    r_gradient += r_mask[mi] * this->image(x, y);
                    c_gradient += c_mask[mi] * this->image(x, y);
                }
            }

            r_gradient /= mask_k + 2, c_gradient /= mask_k + 2;

            magnitude(i, j) = sqrt(pow(r_gradient, 2.0) + pow(c_gradient, 2.0));
            orientation(i, j) = atan2(c_gradient, r_gradient) * 180 / PI;
            if (orientation(i, j) < 0) {
                orientation(i, j) += 180.0;
            }
        }
    }

    return *this;
}

Basic &Basic::generate_laplacian(Matrix<int> &out, const vector<int> &mask) {
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            for (int k = i - 1, mi = 0; k <= i + 1; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 1; l <= j + 1; l++, mi++) {
                    int y = symmetry(l, this->image.cols);
                    out(i, j) += mask[mi] * this->image(x, y);
                }
            }
            out(i, j) /= mask[4];
        }
    }

    return *this;
}

Basic &Basic::generate_zero_crossing(Matrix<unsigned char> &out, Matrix<int> &laplacian,
                                     int threshold) {
    for (int i = 0; i < this->image.size(); i++) {
        if (abs(laplacian.data[i]) <= threshold) {
            laplacian.data[i] = 0;
        }
    }

    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            out(i, j) = 0;

            int i_l = symmetry(i - 1, this->image.rows);
            int i_r = symmetry(i + 1, this->image.rows);
            int j_l = symmetry(j - 1, this->image.cols);
            int j_r = symmetry(j + 1, this->image.cols);
            if (laplacian(i, j) * laplacian(i_r, j) < 0) {
                out(i, j) = 255;
            }
            if (laplacian(i, j) * laplacian(i_r, j_r) < 0) {
                out(i, j) = 255;
            }
            if (laplacian(i, j) * laplacian(i, j_r) < 0) {
                out(i, j) = 255;
            }
            if (laplacian(i, j) == 0) {
                if (laplacian(i_l, j) * laplacian(i_r, j) < 0) {
                    out(i, j) = 255;
                }
                if (laplacian(i, j_l) * laplacian(i, j_r) < 0) {
                    out(i, j) = 255;
                }
                if (laplacian(i_l, j_l) * laplacian(i_r, j_r) < 0) {
                    out(i, j) = 255;
                }
                if (laplacian(i_l, j_r) * laplacian(i_r, j_l) < 0) {
                    out(i, j) = 255;
                }
            }
        }
    }

    return *this;
}

Basic &Basic::generate_gaussian(Matrix<unsigned char> &out, double sigma) {
    vector<double> filter(25, 0);
    generate_gaussian_filter(filter, sigma);
    for (int i = 0; i < this->image.rows; i++) {
        for (int j = 0; j < this->image.cols; j++) {
            for (int k = i - 2, fi = 0; k <= i + 2; k++) {
                int x = symmetry(k, this->image.rows);
                for (int l = j - 2; l <= j + 2; l++, fi++) {
                    int y = symmetry(l, this->image.cols);
                    out(i, j) += filter[fi] * this->image(x, y);
                }
            }
        }
    }

    return *this;
}

Basic &Basic::generate_gaussian_filter(vector<double> &filter, double sigma) {
    // sum is for normalization
    double sum = 0.0;

    // generating 5x5 filter
    double s = 2.0 * sigma * sigma;
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            double r = x * x + y * y, index = (x + 2) * 5 + (y + 2);
            filter[index] = (exp(-r / s)) / (PI * s);
            sum += filter[index];
        }
    }

    for (int i = 0; i < 25; i++) {
        filter[i] /= sum;
    }

    return *this;
}

Basic &Basic::generate_non_maximal_suppression(Matrix<unsigned char> &out,
                                               Matrix<unsigned char> &orientation) {
    for (int i = 1; i < this->image.rows - 1; i++) {
        for (int j = 1; j < this->image.cols - 1; j++) {
            double angle = fmod(orientation(i, j) + 22.5, 180.0);
            int dx = 0, dy = 0;

            if (angle >= 0 && angle <= 45) {
                dx = 0, dy = 1;
            } else if (angle > 45 && angle < 90) {
                dx = 1, dy = -1;
            } else if (angle >= 90 && angle <= 135) {
                dx = 1, dy = 0;
            } else if (angle > 135 && angle < 180) {
                dx = 1, dy = 1;
            }

            if ((this->image(i, j) >= this->image(i + dx, j + dy)) &&
                (this->image(i, j) >= this->image(i - dx, j - dy))) {
                out(i, j) = this->image(i, j);
            } else {
                out(i, j) = 0;
            }
        }
    }

    return *this;
}

Basic &Basic::generate_connected_component(Matrix<unsigned char> &out) {
    out = this->image;
    for (int count = 0; count < 10; count++) {
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                if (out(i, j) == 255) {
                    for (int k = i - 1; k <= i + 1; k++) {
                        int x = symmetry(k, this->image.rows);
                        for (int l = j - 1; l <= j + 1; l++) {
                            int y = symmetry(l, this->image.cols);
                            if (out(x, y) == 128) {
                                out(x, y) = 255;
                            }
                        }
                    }
                }
            }
        }

        for (int i = this->image.rows - 1; i >= 0; i--) {
            for (int j = this->image.cols - 1; j >= 0; j--) {
                if (out(i, j) == 255) {
                    for (int k = i - 1; k <= i + 1; k++) {
                        int x = symmetry(k, this->image.rows);
                        for (int l = j - 1; l <= j + 1; l++) {
                            int y = symmetry(l, this->image.cols);
                            if (out(x, y) == 128) {
                                out(x, y) = 255;
                            }
                        }
                    }
                }
            }
        }
    }

    for (int i = 0; i < out.size(); i++) {
        if (out.data[i] == 128) {
            out.data[i] = 0;
        }
    }

    return *this;
}

Basic &Basic::unsharp_masking(double c) {
    Matrix<unsigned char> low_pass(this->image.rows, this->image.cols);
    low_pass_filter(low_pass, 2);

    Matrix<unsigned char> temp(this->image.rows, this->image.cols);
    for (int i = 0; i < this->image.size(); i++) {
        temp(i) = (c * this->image(i) - (1 - c) * low_pass(i)) / (2 * c - 1);
    }
    for (int i = 0; i < this->image.size(); i++) {
        this->image(i) = temp(i);
    }

    return *this;
}

Basic &Basic::unsharp_masking(Matrix<unsigned char> &out, double c) {
    Matrix<unsigned char> low_pass(this->image.rows, this->image.cols);
    low_pass_filter(low_pass, 2);

    Matrix<unsigned char> temp(this->image.rows, this->image.cols);
    for (int i = 0; i < this->image.size(); i++) {
        temp(i) = (c * this->image(i) - (1 - c) * low_pass(i)) / (2 * c - 1);
    }
    for (int i = 0; i < out.size(); i++) {
        out(i) = temp(i);
    }

    return *this;
}

#endif
