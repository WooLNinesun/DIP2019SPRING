#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 512
#define PI 3.1415926535

class Solution : public Basic {
  public:
    Solution(const char *filepath, unsigned height, unsigned width)
        : Basic(filepath, height, width) {}
    Solution() : Basic() {}

  public:
    static const vector<vector<double>> laws_mask;

    void convolution(Matrix<double> &out, vector<double> mask) {
        for (int i = 1; i < IMG_SIZE - 1; i++) {
            for (int j = 1; j < IMG_SIZE - 1; j++) {
                for (int k = i - 1, mi = 1; k <= i + 1; k++) {
                    for (int l = j - 1; l <= j + 1; l++, mi++) {
                        out(i, j) += double(this->image(k, l)) * mask[mi];
                    }
                }
                out(i, j) /= mask[0];
            }
        }
    }

    Solution &laws_method(vector<Matrix<double>> &T, int winsize) {
        vector<Matrix<double>> M(9);
        for (int i = 0; i < 9; i++) {
            M[i].resize(this->image.rows, this->image.cols, 0);
        }

        int half = winsize / 2;
        for (int m = 0; m < 9; m++) {
            convolution(M[m], laws_mask[m]);
            for (int i = half; i < IMG_SIZE - half; i++) {
                for (int j = half; j < IMG_SIZE - half; j++) {
                    for (int k = i - half; k <= j + half; k++) {
                        for (int l = j - half; l <= j + half; l++) {
                            T[m](i, j) += pow(M[m](k, l), 2);
                        }
                    }
                }
            }
        }
        return *this;
    }
};

int main(int argc, char *argv[]) {
    if (argc == 2) {
        try {
            Solution sample(argv[1], IMG_SIZE, IMG_SIZE);

            vector<Matrix<double>> T(9);
            for (int i = 0; i < 9; i++) {
                T[i].resize(IMG_SIZE, IMG_SIZE, 0);
            }
            sample.laws_method(T, 15);

        } catch (const char err[]) {
            printf("%s\n", err);
        }
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}

const vector<vector<double>> Solution::laws_mask = {
    {36, 1, 2, 1, 2, 4, 2, 1, 2, 1},       {12, 1, 0, -1, 2, 0, -2, 1, 0, -1},
    {12, -1, 2, -1, -2, 4, -2, -1, 2, -1}, {12, -1, -2, -1, 0, 0, 0, 1, 2, 1},
    {4, 1, 0, -1, 0, 0, 0, -1, 0, 1},      {4, -1, 2, -1, 0, 0, 0, 1, -2, 1},
    {12, -1, -2, -1, 2, 4, 2, -1, -2, -1}, {4, -1, 0, 1, 2, 0, -2, -1, 0, 1},
    {4, 1, -2, 1, -2, 4, -2, 1, -2, 1},
};
