#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <string>
#include <vector>

#include "../basic.h"

using namespace std;

#define IMG_SIZE 256
#define PI 3.1415926535

class Solution : public Basic {
  public:
    Solution(const char *filepath, unsigned height, unsigned width)
        : Basic(filepath, height, width) {}
    Solution() : Basic() {}

    // Digital Image processing, 3rd Edition, Table 14.3-1, pp.413,414
    // Shrink, Thin, and Skeletonize Conditional Mark Patterns [M = 1 if hit]
    // the value which represents black in the binary image
    static const unsigned char I = 255;
    static const vector<vector<unsigned char>> conditional_patterns;

    // Digital Image processing, 3rd Edition, Table 14.3-I, p. 414
    // Shrink, Thin, and Skeletonize Unconditional Mark Patterns
    // P(M,M0,M1,M2,M3,M4,M5,M6,M7) = 1 if hit]

    // A ∪ B ∪ C = 1, A ∪ B = 1, D = 0 ∪ 1
    static const unsigned char M = 1;
    static const unsigned char A = 2;
    static const unsigned char B = 3;
    static const unsigned char C = 4;
    static const unsigned char D = 5;
    static const vector<vector<unsigned char>> ST_unconditional_patterns;
    void mark_conditional(Matrix<unsigned char> &out,
                          vector<vector<unsigned char>> table) {
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                vector<unsigned char> pixel_stack;
                for (int k = i - 1; k <= i + 1; k++) {
                    int x = symmetry(k, this->image.rows);
                    for (int l = j - 1; l <= j + 1; l++) {
                        int y = symmetry(l, this->image.cols);
                        pixel_stack.push_back(this->image(x, y));
                    }
                }
                for (int it = 0; it < table.size(); it++) {
                    if (table[it] == pixel_stack) {
                        out(i, j) = M;
                        break;
                    }
                }
            }
        }
    }
    bool match_unconditional(vector<unsigned char> &pixel_stack,
                             vector<unsigned char> &pattern) {
        bool have_ab = false, have_c = false;
        bool a = false, b = false, c = false;
        for (int i = 0; i < pattern.size(); i++) {
            switch (pattern[i]) {
            case 0:
                if (pixel_stack[i] == M) {
                    return false;
                }
                break;
            case Solution::M:
                if (pixel_stack[i] == 0) {
                    return false;
                }
                break;
            case Solution::A:
                if (pixel_stack[i] == M) {
                    a = true;
                } else {
                    have_ab = true;
                }
                break;
            case Solution::B:
                if (pixel_stack[i] == M) {
                    b = true;
                } else {
                    have_ab = true;
                }
                break;
            case Solution::C:
                if (pixel_stack[i] == M) {
                    c = true;
                } else {
                    have_c = true;
                }
                break;
            case Solution::D:
                break;
            default:
                break;
            }
        }

        if (have_c == true) {
            return a || b || c;
        }
        if (have_ab == true) {
            return a || b;
        }
        return true;
    }
    void mark_unconditional(Matrix<unsigned char> &out,
                            vector<vector<unsigned char>> patterns) {
        Matrix<unsigned char> conditional(out);
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                if (conditional(i, j) == 0) {
                    continue;
                }
                vector<unsigned char> pixel_stack;
                for (int k = i - 1; k <= i + 1; k++) {
                    int x = symmetry(k, this->image.rows);
                    for (int l = j - 1; l <= j + 1; l++) {
                        int y = symmetry(l, this->image.cols);
                        pixel_stack.push_back(conditional(x, y));
                    }
                }
                vector<vector<unsigned char>>::iterator it;
                for (it = patterns.begin(); it != patterns.end(); it++) {
                    if (match_unconditional(pixel_stack, *it)) {
                        out(i, j) = 0;
                        break;
                    }
                }
            }
        }
    }
    Solution &shrinking() {
        size_t erasure_count;
        do {
            erasure_count = 0;
            Matrix<unsigned char> conditional(this->image.rows, this->image.cols);
            mark_conditional(conditional, conditional_patterns);
            mark_unconditional(conditional, ST_unconditional_patterns);
            for (int i = 0; i < this->image.size(); i++) {
                if (conditional(i) == M) {
                    this->image(i) = 0;
                    erasure_count++;
                }
            }
        } while (erasure_count > 0);

        return *this;
    }

    Solution &Dilation(Matrix<unsigned char> &out, vector<bool> H) {
        Matrix<unsigned char> temp(this->image.rows + 2, this->image.cols + 2, 0);

        for (int i = 0, hi = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++, hi++) {
                if (H[hi] == 1) {
                    for (int k = 0; k < this->image.rows; k++) {
                        for (int l = 0; l < this->image.cols; l++) {
                            temp(k + i, l + j) |= this->image(k, l);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                this->image(i, j) |= temp(i + 1, j + 1);
            }
        }
        return *this;
    }
    Solution &Dilation(vector<bool> H) {
        Matrix<unsigned char> temp(this->image.rows + 2, this->image.cols + 2, 0);

        for (int i = 0, hi = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++, hi++) {
                if (H[hi] == 1) {
                    for (int k = 0; k < this->image.rows; k++) {
                        for (int l = 0; l < this->image.cols; l++) {
                            temp(k + i, l + j) |= this->image(k, l);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                this->image(i, j) |= temp(i + 1, j + 1);
            }
        }
        return *this;
    }
    Solution &Erosion(Matrix<unsigned char> &out, vector<bool> H) {
        Matrix<unsigned char> temp(this->image.rows + 2, this->image.cols + 2, 255);

        for (int i = 0, hi = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++, hi++) {
                if (H[hi] == 1) {
                    for (int k = 0; k < this->image.rows; k++) {
                        for (int l = 0; l < this->image.cols; l++) {
                            temp(k + i, l + j) &= this->image(k, l);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                out(i, j) &= temp(i + 1, j + 1);
            }
        }
        return *this;
    }
    Solution &Erosion(vector<bool> H) {
        Matrix<unsigned char> temp(this->image.rows + 2, this->image.cols + 2, 255);

        for (int i = 0, hi = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++, hi++) {
                if (H[hi] == 1) {
                    for (int k = 0; k < this->image.rows; k++) {
                        for (int l = 0; l < this->image.cols; l++) {
                            temp(k + i, l + j) &= this->image(k, l);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                this->image(i, j) &= temp(i + 1, j + 1);
            }
        }
        return *this;
    }

    Solution &close(vector<bool> H) {
        vector<bool> H_r(9);
        for (int i = 0; i < H.size(); i++) {
            H_r[i] = !H[i];
        }

        this->Dilation(H).Erosion(H_r);
        return *this;
    }

    Solution &reverse() {
        for (int i = 0; i < this->image.size(); i++) {
            this->image(i) = (this->image(i) == 255) ? 0 : 255;
        }
        return *this;
    }

    bool check_is_dot(int i, int j) {
        for (int k = i - 1, mi = 0; k <= i + 1; k++) {
            int x = symmetry(k, this->image.rows);
            for (int l = j - 1; l <= j + 1; l++, mi++) {
                int y = symmetry(l, this->image.cols);
                if (x == i && y == j) {
                    continue;
                }
                if (this->image(x, y) == 255) {
                    return false;
                }
            }
        }
        return true;
    }

    Solution &find_berries() {
        this->process_edge_detection_1st_order(1, 55).output("1st_order.raw");
        this->close({1, 1, 1, 1, 1, 1, 1, 1, 1}).output("close.raw");
        this->reverse().output("reverse.raw");
        this->shrinking().output("shrinking.raw");

        int count = 0;
        for (int i = 0; i < this->image.rows; i++) {
            for (int j = 0; j < this->image.cols; j++) {
                if (this->image(i, j) == 255 && check_is_dot(i, j)) {
                    count += 1;
                }
            }
        }

        printf("berries: %d\n", count);

        return *this;
    }
};

int main(int argc, char *argv[]) {
    if (argc == 2) {
        try {
            Solution sample(argv[1], IMG_SIZE, IMG_SIZE);

            sample.find_berries();

        } catch (const char err[]) {
            printf("%s\n", err);
        }
    } else {
        printf("Need 1 image file. <inputImageName>");
    }
    return 0;
}
const vector<vector<unsigned char>> Solution::conditional_patterns = {
    {0, 0, I, /**/ 0, I, 0, /**/ 0, 0, 0}, {I, 0, 0, /**/ 0, I, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ 0, I, 0, /**/ I, 0, 0}, {0, 0, 0, /**/ 0, I, 0, /**/ 0, 0, I},
    {0, 0, 0, /**/ 0, I, I, /**/ 0, 0, 0}, {0, I, 0, /**/ 0, I, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ I, I, 0, /**/ 0, 0, 0}, {0, 0, 0, /**/ 0, I, 0, /**/ 0, I, 0},
    {0, 0, I, /**/ 0, I, I, /**/ 0, 0, 0}, {0, I, I, /**/ 0, I, 0, /**/ 0, 0, 0},
    {I, I, 0, /**/ 0, I, 0, /**/ 0, 0, 0}, {I, 0, 0, /**/ I, I, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ I, I, 0, /**/ I, 0, 0}, {0, 0, 0, /**/ 0, I, 0, /**/ I, I, 0},
    {0, 0, 0, /**/ 0, I, 0, /**/ 0, I, I}, {0, 0, 0, /**/ 0, I, I, /**/ 0, 0, I},
    {0, 0, I, /**/ 0, I, I, /**/ 0, 0, I}, {I, I, I, /**/ 0, I, 0, /**/ 0, 0, 0},
    {I, 0, 0, /**/ I, I, 0, /**/ I, 0, 0}, {0, 0, 0, /**/ 0, I, 0, /**/ I, I, I},
    {I, I, 0, /**/ 0, I, I, /**/ 0, 0, 0}, {0, I, 0, /**/ 0, I, I, /**/ 0, 0, I},
    {0, I, I, /**/ I, I, 0, /**/ 0, 0, 0}, {0, 0, I, /**/ 0, I, I, /**/ 0, I, 0},
    {0, I, I, /**/ 0, I, I, /**/ 0, 0, 0}, {I, I, 0, /**/ I, I, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ I, I, 0, /**/ I, I, 0}, {0, 0, 0, /**/ 0, I, I, /**/ 0, I, I},
    {I, I, 0, /**/ 0, I, I, /**/ 0, 0, I}, {0, I, I, /**/ I, I, 0, /**/ I, 0, 0},
    {I, I, I, /**/ 0, I, I, /**/ 0, 0, 0}, {0, I, I, /**/ 0, I, I, /**/ 0, 0, I},
    {I, I, I, /**/ I, I, 0, /**/ 0, 0, 0}, {I, I, 0, /**/ I, I, 0, /**/ I, 0, 0},
    {I, 0, 0, /**/ I, I, 0, /**/ I, I, 0}, {0, 0, 0, /**/ I, I, 0, /**/ I, I, I},
    {0, 0, 0, /**/ 0, I, I, /**/ I, I, I}, {0, 0, I, /**/ 0, I, I, /**/ 0, I, I},
    {I, I, I, /**/ 0, I, I, /**/ 0, 0, I}, {I, I, I, /**/ I, I, 0, /**/ I, 0, 0},
    {I, 0, 0, /**/ I, I, 0, /**/ I, I, I}, {0, 0, I, /**/ 0, I, I, /**/ I, I, I},
    {0, I, I, /**/ 0, I, I, /**/ 0, I, I}, {I, I, I, /**/ I, I, I, /**/ 0, 0, 0},
    {I, I, 0, /**/ I, I, 0, /**/ I, I, 0}, {0, 0, 0, /**/ I, I, I, /**/ I, I, I},
    {I, I, I, /**/ 0, I, I, /**/ 0, I, I}, {0, I, I, /**/ 0, I, I, /**/ I, I, I},
    {I, I, I, /**/ I, I, I, /**/ I, 0, 0}, {I, I, I, /**/ I, I, I, /**/ 0, 0, I},
    {I, I, I, /**/ I, I, 0, /**/ I, I, 0}, {I, I, 0, /**/ I, I, 0, /**/ I, I, I},
    {I, 0, 0, /**/ I, I, I, /**/ I, I, I}, {0, 0, I, /**/ I, I, I, /**/ I, I, I},
    {I, I, I, /**/ 0, I, I, /**/ I, I, I}, {I, I, I, /**/ I, I, I, /**/ I, 0, I},
    {I, I, I, /**/ I, I, 0, /**/ I, I, I}, {I, 0, I, /**/ I, I, I, /**/ I, I, I},
};
const vector<vector<unsigned char>> Solution::ST_unconditional_patterns = {
    // spur
    {0, 0, M, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, 0, 0, /**/ 0, M, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ 0, M, 0, /**/ 0, M, 0},
    {0, 0, 0, /**/ 0, M, M, /**/ 0, 0, 0},
    // L Cluster
    {0, 0, M, /**/ 0, M, M, /**/ 0, 0, 0},
    {0, M, M, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, M, 0, /**/ 0, M, 0, /**/ 0, 0, 0},
    {M, 0, 0, /**/ M, M, 0, /**/ 0, 0, 0},
    {0, 0, 0, /**/ M, M, 0, /**/ M, 0, 0},
    {0, 0, 0, /**/ 0, M, 0, /**/ M, M, 0},
    {0, 0, 0, /**/ 0, M, 0, /**/ 0, M, M},
    {0, 0, 0, /**/ 0, M, M, /**/ 0, 0, M},
    // offset
    {0, M, M, /**/ M, M, 0, /**/ 0, 0, 0},
    {M, M, 0, /**/ 0, M, M, /**/ 0, 0, 0},
    {0, M, 0, /**/ 0, M, M, /**/ 0, 0, M},
    {0, 0, M, /**/ 0, M, M, /**/ 0, M, 0},
    // spur corner
    {0, A, M, /**/ 0, M, B, /**/ M, 0, 0},
    {M, B, 0, /**/ A, M, 0, /**/ 0, 0, M},
    {0, 0, M, /**/ A, M, 0, /**/ M, B, 0},
    {M, 0, 0, /**/ 0, M, B, /**/ 0, A, M},
    // corner clutter
    {M, M, D, /**/ M, M, D, /**/ D, D, D},
    // tee branch
    {D, M, 0, /**/ M, M, M, /**/ D, 0, 0},
    {0, M, D, /**/ M, M, M, /**/ 0, 0, D},
    {0, 0, D, /**/ M, M, M, /**/ 0, M, D},
    {D, 0, 0, /**/ M, M, M, /**/ D, M, 0},
    {D, M, D, /**/ M, M, 0, /**/ 0, M, 0},
    {0, M, 0, /**/ M, M, 0, /**/ D, M, D},
    {0, M, 0, /**/ 0, M, M, /**/ D, M, D},
    {D, M, D, /**/ 0, M, M, /**/ 0, M, 0},
    // vee branch
    {M, D, M, /**/ D, M, D, /**/ A, B, C},
    {M, D, C, /**/ D, M, B, /**/ M, D, A},
    {C, B, A, /**/ D, M, D, /**/ M, D, M},
    {A, D, M, /**/ B, M, D, /**/ C, D, M},
    // diagonal branch
    {D, M, 0, /**/ 0, M, M, /**/ M, 0, D},
    {0, M, D, /**/ M, M, 0, /**/ D, 0, M},
    {D, 0, M, /**/ M, M, 0, /**/ 0, M, D},
    {M, 0, D, /**/ 0, M, M, /**/ D, M, 0},
};
