#include <string>
#include <vector>

#include "matrix.h"

#ifndef __BASIC_H
#define __BASIC_H

using namespace std;

#define PI 3.1415926535

class Basic {
  public:
    Matrix<unsigned char> origin;
    Matrix<unsigned char> image;

  public:
    static const vector<int> Prewitt_mask;
    static const vector<int> Sobel_mask;
    static const vector<int> four_neighbor_mask;
    static const vector<int> eight_neighbor_non_separable_mask;
    static const vector<int> eight_neighbor_separable_mask;
    static const vector<int> high_pass_filter_5;
    static const vector<int> high_pass_filter_9;

  public:
    Basic();
    Basic(const char *filepath, unsigned height, unsigned width);

    int symmetry(int n, int bound);

  public:
    Basic &reset();
    Basic &output(const char *filepath);

    // homework1
    Basic &horizontal_flipping();
    Basic &power_law(double p);
    Basic &intensity_dividing(unsigned d);
    Basic &global_equalize_hist();
    Basic &local_equalize_hist(unsigned window_size);
    Basic &low_pass_filter(double b);
    Basic &low_pass_filter(Matrix<unsigned char> &out, double b);
    Basic &high_pass_filter(int mask_num);
    Basic &high_pass_filter(Matrix<unsigned char> &out, int mask_num);
    Basic &outlier_detection(double e);
    Basic &median_filtering();
    double computer_mse(const vector<unsigned char> &a);
    double computer_psnr(const vector<unsigned char> &a);

    // homework2
    Basic &process_edge_detection_1st_order(int mask_k, int threshold);
    Basic &process_edge_detection_2nd_order(double gaussian_sigma, int threshold);
    Basic &process_edge_detection_canny(double gaussian_sigma, int low_threshold,
                                        int high_threshold);
    Basic &generate_gradient(Matrix<unsigned char> &magnitude,
                             Matrix<unsigned char> &orientation, vector<int> mask);
    Basic &generate_laplacian(Matrix<int> &out, const vector<int> &mask);
    Basic &generate_zero_crossing(Matrix<unsigned char> &out, Matrix<int> &laplacian,
                                  int threshold);
    Basic &generate_gaussian(Matrix<unsigned char> &out, double sigma);
    Basic &generate_gaussian_filter(vector<double> &filter, double sigma);
    Basic &generate_non_maximal_suppression(Matrix<unsigned char> &out,
                                            Matrix<unsigned char> &orientation);
    Basic &generate_connected_component(Matrix<unsigned char> &out);
    Basic &unsharp_masking(double c);
    Basic &unsharp_masking(Matrix<unsigned char> &out, double c);
};

#include "basic.cpp"

#endif
